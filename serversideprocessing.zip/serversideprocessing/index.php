<!Doctype html>
<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="asset/css/jquery.dataTables.min.css">
	
</head>
<body>
<table id="example" class="display" style="width:100%">
        <thead>
            <tr>
                <th>id</th>
                <th>name</th>
            </tr>
        </thead>
        <tfoot>
            <tr>
                <th>id</th>
                <th>name</th>

            </tr>
        </tfoot>
    </table>
 <!--<script  src="../../asset/js/jquery-3.5.1.js"></script>-->
<script type="text/javascript" src="asset/js/jquery-3.5.1.js"></script>
<script src="asset/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="asset/js/dataTables.bootstrap.min.js"></script>
<script type="text/javascript">
		
$(document).ready(function() {
    $('#example').DataTable( {  
        "scrollX": true,
        "pagingType": "numbers",
        "processing": true,
        "serverSide": true,
        "ajax": "server_processing.php"
    } );
} );
</script>
</body>
</html>
